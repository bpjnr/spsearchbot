$(document).ready(function() {

	$.ajax({
        url: '/searchHashTag',
        data: $('#frmSearchHashTag').serialize(),
        type: 'POST',
        dataType: "json",
        success: function(response) {
        	getPieData(response);
        	//var data = JSON.parse(response);
            console.log(response);

			//$('.chart').html(result);
			//alert('ok');
        },
        error: function(error) {
            console.log(error);
        }
    });


	$('.search').click(function(e) {
		e.preventDefault();
        $.ajax({
            url: '/searchHashTag',
            data: $('#frmSearchHashTag').serialize(),
            type: 'POST',
            dataType: "json",
            success: function(response) {
            	getPieData(response);
            	//var data = JSON.parse(response);
                console.log(response);

				//$('.chart').html(result);
				//alert('ok');
            },
            error: function(error) {
                console.log(error);
            }
        });
    });

    /*$('.chart').highcharts({
		chart: chart,
		title: title,
		series: series,
		credits: credits
	});*/
});

function getPieData (data) {
   $('.chart').highcharts({
	    chart : {
	                "plotBackgroundColor": "#fff",
	                "plotBorderWidth": "null",
	                "plotShadow": "false",
	                "type": "pie"
	            },
	    series : data,
	    title : {"text": '#hashTag Analysis Result'},
	    credits : {"text":"Say Peace Technologies"},
	    tooltip: { "pointFormat": '{series.name}: <b>{point.percentage:.1f}%</b>'},
	    plotOptions: {
	                    "pie": {
	                        "allowPointSelect": "true",
	                        "cursor": 'pointer',
	                        "dataLabels": {
	                            "enabled": "true"
	                        },
	                        "showInLegend": "true"
	                    }
	                },
	});
}